import { useState } from "react";
import "./App.css";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:8000";

function App() {
  const [prompt, setPrompt] = useState("");
  const [code, setCode] = useState("");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    setLoading(true);
    const res = await fetch(`${API_URL}/api/v1/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, previous_code: code })
    });
    const data = await res.json();
    setCode(data.code);
    setLoading(false);
  };

  const run = async () => {
    setOutput("");
    const res = await fetch(`${API_URL}/api/v1/execute`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code })
    });
    const data = await res.json();
    setOutput(data.stdout || data.stderr);
  };

  return (
    <div className="app">
      <h2>&gt; AKN<span className="cursor">_</span></h2>

      <textarea
        placeholder="Describe your app..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />

      <div className="buttons">
        <button onClick={generate} disabled={loading}>
          {loading ? "Generating..." : "⚡ Generate"}
        </button>

        <button onClick={run} disabled={!code}>
          ▶ Run
        </button>
      </div>

      <pre className="code">{code}</pre>

      <h3>Output:</h3>
      <pre className="output">{output}</pre>
    </div>
  );
}

export default App;